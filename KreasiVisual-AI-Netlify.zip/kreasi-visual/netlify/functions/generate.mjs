const json = (statusCode, body) => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  },
  body: JSON.stringify(body)
});

const clean = (value, max = 500) => String(value ?? '').trim().slice(0, max);
const recentRequests = new Map();

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return json(200, { ok: true });
  if (event.httpMethod !== 'POST') return json(405, { error: 'Gunakan metode POST.' });
  const ip = event.headers?.['x-nf-client-connection-ip'] || event.headers?.['x-forwarded-for']?.split(',')[0] || 'unknown';
  const now = Date.now();
  const recent = (recentRequests.get(ip) || []).filter((time) => now - time < 60 * 60 * 1000);
  if (recent.length >= 5) return json(429, { error: 'Batas sementara tercapai. Coba lagi sekitar satu jam kemudian.' });
  recent.push(now); recentRequests.set(ip, recent);

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return json(503, { error: 'AI belum diaktifkan. Pemilik website perlu mengisi OPENAI_API_KEY pada Netlify Environment Variables lalu deploy ulang.' });

  try {
    const body = JSON.parse(event.body || '{}');
    const business = clean(body.business, 60);
    const category = clean(body.category, 100);
    const tagline = clean(body.tagline, 120);
    const detail = clean(body.detail, 400);
    const contact = clean(body.contact, 80);
    const brief = clean(body.brief, 700);
    const style = clean(body.style, 60);
    const palette = clean(body.palette, 60);
    const type = clean(body.type, 30);
    const variation = Math.max(1, Math.min(3, Number(body.variation) || 1));
    if (!business) return json(400, { error: 'Nama usaha wajib diisi.' });
    if (body.imageData && String(body.imageData).length > 5_500_000) return json(413, { error: 'Foto terlalu besar. Coba gunakan foto dengan ukuran lebih kecil.' });

    const dimensions = type === 'logo' || type === 'social'
      ? '1024x1024'
      : '1024x1536';

    const results = [];
    for (let i = 0; i < variation; i++) {
      const artDirection = [
        'high-end editorial art direction, asymmetrical grid, striking typography-safe negative space, sophisticated crop',
        'bold contemporary campaign art direction, layered geometric forms, unexpected composition, premium color blocking',
        'playful modern independent-brand art direction, tactile textures, dynamic framing, distinctive visual rhythm'
      ][i];
      const prompt = `Create a genuinely original, professional commercial graphic-design key visual for a contemporary Indonesian small business brand. This must look art-directed by a senior graphic designer, not like a generic template.\n\nBrand: ${business}. Product/category: ${category || 'small business product'}. Campaign message: ${tagline || 'A fresh campaign for this brand'}. Details: ${detail || 'Make the product desirable and memorable.'}. Contact context: ${contact || 'No contact text required'}.\n\nCreative brief from user: ${brief || 'Create a visually memorable promotional campaign.'}. Design style: ${style}. Color direction: ${palette}.\n\nArt direction for this variation: ${artDirection}. Variation ${i + 1}: make the visual concept and composition clearly distinct.\n\nOutput: ${dimensions === '1024x1024' ? 'square 1:1' : 'portrait 2:3'} campaign artwork. Create rich, realistic product photography or premium 3D product styling, beautiful lighting, deliberate composition, refined material details, layered depth, tasteful texture and professional color grading. Reserve a calm, uncluttered text-safe area in the lower 30 percent for a headline overlay. Do not generate any text, letters, numbers, watermark, fake logo, typography or UI. Do not invent extra products or brand marks. The visual should feel current, polished, premium and genuinely distinctive.`;

      let response;
      if (body.imageData) {
        const match = String(body.imageData).match(/^data:(image\/(?:png|jpeg|webp));base64,([\s\S]+)$/);
        if (!match) return json(400, { error: 'Format foto harus PNG, JPG, atau WEBP.' });
        const mime = match[1];
        const bytes = Buffer.from(match[2], 'base64');
        const ext = mime === 'image/jpeg' ? 'jpg' : mime.split('/')[1];
        const form = new FormData();
        form.append('model', 'gpt-image-1');
        form.append('prompt', `Edit and art-direct the uploaded product photo into a premium advertising campaign visual. Preserve the exact identity, shape, packaging, colors and recognizable details of the uploaded product. Do not redesign its label or change the product. ${prompt}`);
        form.append('size', dimensions);
        form.append('quality', 'high');
        form.append('output_format', 'png');
        form.append('image', new Blob([bytes], { type: mime }), `product.${ext}`);
        response = await fetch('https://api.openai.com/v1/images/edits', {
          method: 'POST',
          headers: { Authorization: `Bearer ${apiKey}` },
          body: form
        });
      } else {
        response = await fetch('https://api.openai.com/v1/images/generations', {
          method: 'POST',
          headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: 'gpt-image-1', prompt, size: dimensions,
            quality: 'high', output_format: 'png'
          })
        });
      }

      const result = await response.json();
      if (!response.ok) {
        const message = result?.error?.message || 'Layanan AI gagal membuat gambar.';
        const status = response.status === 401 ? 502 : response.status;
        return json(status, { error: message });
      }
      const image = result?.data?.[0]?.b64_json;
      if (!image) return json(502, { error: 'AI tidak mengembalikan gambar. Silakan coba lagi.' });
      results.push(image);
    }
    return json(200, { images: results, model: 'gpt-image-1' });
  } catch (error) {
    return json(500, { error: error?.message || 'Terjadi kesalahan saat menghubungi AI.' });
  }
};
