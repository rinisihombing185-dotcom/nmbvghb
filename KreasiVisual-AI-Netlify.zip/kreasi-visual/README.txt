KREASI VISUAL AI — NETLIFY

APA YANG BERUBAH
- Website kini memanggil OpenAI Image API melalui Netlify Function.
- AI membuat visual baru berdasarkan brief, gaya, palet, dan jenis desain.
- Foto produk dapat diunggah untuk diedit menjadi visual kampanye.
- Bisa meminta 1, 2, atau 3 alternatif dalam satu proses.
- Teks promosi ditambahkan di browser agar lebih tajam dan mudah dibaca.
- API key tidak ditulis di HTML atau file ZIP.

PENTING: AKTIFKAN API SECARA AMAN
1. API key yang pernah ditempel di chat harus di-revoke. Jangan gunakan key tersebut lagi.
2. Buat API key BARU di https://platform.openai.com/api-keys.
3. Buka Netlify Dashboard > pilih site > Site configuration > Environment variables.
4. Tambahkan variable bernama OPENAI_API_KEY dengan value API key BARU.
5. Jangan menaruh key di index.html, GitHub publik, atau membagikannya kepada siapa pun.
6. Jalankan deploy ulang (Deploys > Trigger deploy > Deploy site).
7. Buka website yang sudah online dan coba generate desain.

CARA DEPLOY
1. Ekstrak ZIP ini.
2. Unggah isi folder kreasi-visual ke Netlify (folder berisi index.html, netlify.toml, dan folder netlify).
3. Pastikan folder netlify/functions/generate.mjs ikut terunggah. Netlify Functions tidak akan aktif jika hanya index.html yang diunggah.
4. Atur OPENAI_API_KEY seperti petunjuk di atas.

BIAYA DAN KEAMANAN
- ChatGPT Plus/Free dan OpenAI API adalah layanan penagihan terpisah. Panggilan gambar API dapat menimbulkan biaya.
- Satu generate dengan 2 atau 3 alternatif akan membuat 2 atau 3 permintaan gambar.
- Jangan publikasikan endpoint berbayar tanpa pembatasan akses. Function ini memiliki pembatas sementara sederhana per alamat IP, tetapi penyimpanan pembatas pada instance serverless tidak permanen/terdistribusi dan bukan perlindungan lengkap.
- Sebelum membagikan website secara luas, tambahkan login atau kode akses, rate limiting persisten, dan batas anggaran/pemantauan penggunaan di akun API.
- Batas 5 sesi pada tampilan browser hanyalah penghitung demo lokal dan dapat direset pengguna. Itu bukan sistem billing.

MODEL
Function menggunakan model gambar gpt-image-1 melalui endpoint Images API. Jika akun API belum memiliki akses atau billing aktif, layanan akan mengembalikan pesan error dari API.
